﻿using System;

namespace MISA.Infrastructure
{
    public class Class1
    {
    }
}
