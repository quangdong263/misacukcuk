﻿using System;

namespace MISA.ApplicationCore
{
    public class Class1
    {
    }
}
