﻿////const apiKeySid = 'SKbITe5mwtWKCB2wRWi9Wnyxux2NSCepAY';
////const apiKeySecret = 'ZGVkYjRZZ1d6eENXVjRZdXFhbmZkUmFYVFUyaUZsTzY=';
////const userId = `${(Math.random() * 100000).toFixed(6)}`;

////var token = getAccessToken();
////console.log(token);


////function getAccessToken() {
////	var now = Math.floor(Date.now() / 1000);
////	var exp = now + 3600;

////	var header = { cty: "stringee-api;v=1" };
////	var payload = {
////		jti: apiKeySid + "-" + now,
////		iss: apiKeySid,
////		exp: exp,
////		userId: userId
////	};

////	var jwt = require('jsonwebtoken');
////	var token = jwt.sign(payload, apiKeySecret, { algorithm: 'HS256', header: header })
////	return token;
////}