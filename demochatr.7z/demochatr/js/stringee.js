const apiKeySid = 'SKbITe5mwtWKCB2wRWi9Wnyxux2NSCepAY';
const apiKeySecret = 'ZGVkYjRZZ1d6eENXVjRZdXFhbmZkUmFYVFUyaUZsTzY=';
const userId = `${(Math.random() * 100000).toFixed(6)}`;

//var token = getAccessToken();
//console.log(token);


//const x = function getAccessToken() {
//	var now = Math.floor(Date.now() / 1000);
//	var exp = now + 3600;

//	var header = { cty: "stringee-api;v=1" };
//	var payload = {
//		jti: apiKeySid + "-" + now,
//		iss: apiKeySid,
//		exp: exp,
//		userId: userId
//	};

//	var jwt = require('jsonwebtoken');
//	var token = jwt.sign(payload, apiKeySecret, { algorithm: 'HS256', header: header })
//	return token;
//}







const connectStringee = async function () {
    var stringeeClient = new StringeeClient();

    stringeeClient.on('connect', function () {
        console.log('++++++++++++++ connected to StringeeServer');
    });

    stringeeClient.on('authen', function (res) {
        console.log('authen', res);
    });

    stringeeClient.on('disconnect', function () {
        console.log('++++++++++++++ disconnected');
    });

    stringeeClient.connect("eyJjdHkiOiJzdHJpbmdlZS1hcGk7dj0xIiwidHlwIjoiSldUIiwiYWxnIjoiSFMyNTYifQ.eyJqdGkiOiJTS2JJVGU1bXd0V0tDQjJ3UldpOVdueXh1eDJOU0NlcEFZLTE2MTg4Mjk1MzEiLCJpc3MiOiJTS2JJVGU1bXd0V0tDQjJ3UldpOVdueXh1eDJOU0NlcEFZIiwiZXhwIjoxNjIxNDIxNTMxLCJ1c2VySWQiOiJ1c2VyMiJ9.qNQ9eGOHYZ7JJ5d5PwsUgc_YQsbnvxD3J3GVB8S2Gow");

    


    setTimeout(() => {
        var stringeeChat;

        var userIds = ["user2"];

        var options = {
            name: "Your conversation name",
            isDistinct: false,
            isGroup: false
        };
        stringeeChat = new StringeeChat(stringeeClient);


        stringeeChat.createConversation(userIds, options, (status, code, message, conv) => {
            console.log('status:' + status + ' code:' + code + ' message:' + message + ' conv:' + JSON.stringify(conv));
        });
        //stringeeClient.disconnect();
    }, 1000)
    // init

}


connectStringee();



