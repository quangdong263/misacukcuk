﻿using Newtonsoft.Json;
using quanggm.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace quanggm.Pages
{
    public partial class EmployeePage
    {
        private enum MODE { None, Edit };
        MODE mode = MODE.None;

        protected Employee emp = new Employee();
        protected bool IsVisible = false;
        protected bool isAddEmployye = false;
        protected bool isEditEmployye = false;
        protected bool isOpenDialogAddRole = false;

        private void OpenDialogAddRole()
        {
            this.isOpenDialogAddRole = true;
        }
        private void CloseDialogAddRole()
        {
            this.isOpenDialogAddRole = false;
        }
        List<Employee> listEmployee;
        protected override async Task OnInitializedAsync()
        {
            //var service = new EmployeeServicecs();
            //listEmployee = await service.GetEmployees();

            //var js = await Http.PostAsJsonAsync ("http://localhost:55758/api/v1/employees","");
            //string jscontent = js.Content.ReadAsStringAsync().Result;
            //Console.WriteLine(jscontent);
            //var data = JsonConvert.DeserializeObject<List<Employee>>(jscontent);
            listEmployee = await GetEmployees();
        }


        public async Task<System.Collections.Generic.List<Employee>> GetEmployees()
        {

            var js = await Http.GetAsync("http://localhost:55758/api/v1/employees");
            string jscontent = js.Content.ReadAsStringAsync().Result;
            Console.WriteLine(jscontent);
            var data = JsonConvert.DeserializeObject<List<Employee>>(jscontent);
            return data;
        }
        protected async Task DeleleEmployee(string id)
        {
            await Http.DeleteAsync($"http://localhost:55758/api/v1/employees/{id}");
            closeConfirmDelete();
            await OnInitializedAsync();


        }
        protected void DeleteConfirm(string empID)
        {

            emp = listEmployee.FirstOrDefault(x => x.EmployeeId.ToString() == empID);
            this.IsVisible = true;
        }
        protected void closeConfirmDelete()
        {
            this.IsVisible = false;
        }

        private void openDialogAdd()
        {
            this.isAddEmployye = true;
            emp = new Employee();

        }
        private void closeDialogAdd()
        {
            this.isAddEmployye = false;
        }
        private void CloseDialogEdit()
        {
            this.isEditEmployye = false;
        }
        private async Task HandleValidSubmit()
        {
            await Http.PostAsJsonAsync("http://localhost:55758/api/v1/employees", emp);
            closeDialogAdd();

            await OnInitializedAsync();

        }
        protected async Task UpdateEmployee()
        {
            await Http.PutAsJsonAsync($"http://localhost:55758/api/v1/employees/{emp.EmployeeId}", emp);
            CloseDialogEdit();
            await OnInitializedAsync();


        }
        protected void EditEmployee(string id)
        {
            emp = listEmployee.FirstOrDefault(x => x.EmployeeId.ToString() == id);
            this.isEditEmployye = true;

        }
    }
}
